/**
 * Omnee Courier Solutions - Backend Intake Form Submission Handler
 * 
 * Target Recipient: info@omneecourier.com
 * Subject Line Format: [DISPATCH TICKET] {Category} - {Company Name} ({Contact Name})
 * 
 * Compatible with Express.js, Next.js API Routes, or standalone Node.js serverless functions.
 * Supports Nodemailer (SMTP), SendGrid, or direct email transport.
 */

import { Request, Response } from 'express';

export interface IntakeRequestBody {
  name: string;
  email: string;
  phone: string;
  company: string;
  isQuoteInquiry: boolean;
  subject: string;
  categoryData?: {
    medicalSpecs?: {
      temperatureControl?: string;
      specimenTypes?: string[];
      chainOfCustodyDoc?: string;
      facilityPickupType?: string;
    };
    statSpecs?: {
      pickupAddressFacility?: string;
      destinationAddressFacility?: string;
      dispatchPriorityWindow?: string;
      onSitePickupContactPhone?: string;
      packageDimensionsWeight?: string;
    };
    vetSpecs?: {
      animalHospitalClinicLocation?: string;
      sweepFrequency?: string;
      targetCutoffTime?: string;
      estimatedDailyCount?: string;
    };
    afterHoursSpecs?: {
      coverageShifts?: string[];
      facilityAccessProtocol?: string;
      coverageRange?: string;
    };
    corporateSpecs?: {
      accountsPayableEmail?: string;
      estimatedMonthlyVolume?: string;
      preferredBillingCycle?: string;
    };
    generalSpecs?: {
      topicSummary?: string;
    };
  };
  message: string;
}

const TARGET_RECIPIENT = 'info@omneecourier.com';

/**
 * Formats the email HTML payload into a clean, modern, responsive table.
 */
export function buildIntakeEmailHtml(data: IntakeRequestBody): string {
  const cd = data.categoryData || {};
  let categorySpecsHtml = '';

  if (data.subject === 'Medical Courier Specifications' && cd.medicalSpecs) {
    categorySpecsHtml = `
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569; width: 35%;">Temperature Control</td><td style="padding: 8px 12px; color: #0f172a;">${cd.medicalSpecs.temperatureControl || 'Ambient'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Specimen / Transport Types</td><td style="padding: 8px 12px; color: #0f172a;">${(cd.medicalSpecs.specimenTypes || []).join(', ') || 'None specified'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Chain of Custody / Biohazard Doc</td><td style="padding: 8px 12px; color: #0f172a;">${cd.medicalSpecs.chainOfCustodyDoc || 'Yes'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Facility Pickup Type</td><td style="padding: 8px 12px; color: #0f172a;">${cd.medicalSpecs.facilityPickupType || 'Outpatient Clinic'}</td></tr>
    `;
  } else if (data.subject === 'STAT Emergency Dispatch' && cd.statSpecs) {
    categorySpecsHtml = `
      <tr style="background-color: #fff1f2;"><td style="padding: 8px 12px; font-weight: bold; color: #9f1239; width: 35%;">Pickup Address & Facility</td><td style="padding: 8px 12px; color: #881337; font-weight: bold;">${cd.statSpecs.pickupAddressFacility || 'N/A'}</td></tr>
      <tr style="background-color: #fff1f2;"><td style="padding: 8px 12px; font-weight: bold; color: #9f1239;">Destination Address & Facility</td><td style="padding: 8px 12px; color: #881337; font-weight: bold;">${cd.statSpecs.destinationAddressFacility || 'N/A'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Dispatch Priority Window</td><td style="padding: 8px 12px; color: #b91c1c; font-weight: bold;">${cd.statSpecs.dispatchPriorityWindow || 'Immediate'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">On-Site Pickup Phone</td><td style="padding: 8px 12px; color: #0f172a;">${cd.statSpecs.onSitePickupContactPhone || 'N/A'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Cargo Dimensions & Weight</td><td style="padding: 8px 12px; color: #0f172a;">${cd.statSpecs.packageDimensionsWeight || 'Standard'}</td></tr>
    `;
  } else if (data.subject === 'Veterinary Diagnostic Route Setup' && cd.vetSpecs) {
    categorySpecsHtml = `
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569; width: 35%;">Animal Hospital / Clinic</td><td style="padding: 8px 12px; color: #0f172a;">${cd.vetSpecs.animalHospitalClinicLocation || 'Not provided'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Sweep Frequency</td><td style="padding: 8px 12px; color: #0f172a;">${cd.vetSpecs.sweepFrequency || 'Daily'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Target Cutoff Time</td><td style="padding: 8px 12px; color: #0f172a;">${cd.vetSpecs.targetCutoffTime || '5:00 PM'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Estimated Daily Packages</td><td style="padding: 8px 12px; color: #0f172a;">${cd.vetSpecs.estimatedDailyCount || '1–5 packages'}</td></tr>
    `;
  } else if (data.subject === 'Dedicated After-Hours Route Coverage' && cd.afterHoursSpecs) {
    categorySpecsHtml = `
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569; width: 35%;">Coverage Shifts</td><td style="padding: 8px 12px; color: #0f172a;">${(cd.afterHoursSpecs.coverageShifts || []).join(', ') || 'N/A'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Facility Access Protocol</td><td style="padding: 8px 12px; color: #0f172a;">${cd.afterHoursSpecs.facilityAccessProtocol || 'Key / Lockbox'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Service Coverage Range</td><td style="padding: 8px 12px; color: #0f172a;">${cd.afterHoursSpecs.coverageRange || 'Local Flagstaff'}</td></tr>
    `;
  } else if (data.subject === 'Corporate Account Setup / Billing & Invoicing Query' && cd.corporateSpecs) {
    categorySpecsHtml = `
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569; width: 35%;">Accounts Payable Email</td><td style="padding: 8px 12px; color: #0f172a;">${cd.corporateSpecs.accountsPayableEmail || 'Same as primary contact'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Monthly Shipment Volume</td><td style="padding: 8px 12px; color: #0f172a;">${cd.corporateSpecs.estimatedMonthlyVolume || '1–25'}</td></tr>
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569;">Preferred Billing Cycle</td><td style="padding: 8px 12px; color: #0f172a;">${cd.corporateSpecs.preferredBillingCycle || 'Monthly'}</td></tr>
    `;
  } else if (cd.generalSpecs?.topicSummary) {
    categorySpecsHtml = `
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569; width: 35%;">Topic Summary</td><td style="padding: 8px 12px; color: #0f172a;">${cd.generalSpecs.topicSummary}</td></tr>
    `;
  } else {
    categorySpecsHtml = `
      <tr><td style="padding: 8px 12px; font-weight: bold; color: #475569; width: 35%;">Logistics Scope</td><td style="padding: 8px 12px; color: #0f172a;">Standard Northern Arizona Logistics Inquiry</td></tr>
    `;
  }

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>Omnee Courier Intake</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; padding: 24px; color: #0f172a;">
        <table align="center" width="100%" cellpadding="0" cellspacing="0" style="max-width: 650px; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
          <!-- Header -->
          <tr style="background-color: #0f172a; color: #ffffff;">
            <td style="padding: 24px; text-align: left;">
              <h2 style="margin: 0; font-size: 20px; font-weight: 800; letter-spacing: -0.5px;">OMNEE COURIER SOLUTIONS</h2>
              <p style="margin: 4px 0 0 0; font-size: 12px; color: #93c5fd; text-transform: uppercase; letter-spacing: 1px;">Dispatch Ticket Intake Notification</p>
            </td>
          </tr>

          <!-- Section 1: Contact Info -->
          <tr>
            <td style="padding: 20px 24px 10px 24px;">
              <h3 style="margin: 0 0 12px 0; font-size: 13px; font-weight: 800; text-transform: uppercase; color: #1e3a8a; letter-spacing: 0.5px; border-bottom: 2px solid #dbeafe; padding-bottom: 6px;">
                1. Contact & Facility Profile
              </h3>
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 13px; border-collapse: collapse;">
                <tr><td style="padding: 6px 0; font-weight: bold; color: #475569; width: 35%;">Contact Name:</td><td style="padding: 6px 0; color: #0f172a; font-weight: 600;">${data.name}</td></tr>
                <tr><td style="padding: 6px 0; font-weight: bold; color: #475569;">Email Address:</td><td style="padding: 6px 0;"><a href="mailto:${data.email}" style="color: #2563eb; text-decoration: none; font-weight: 600;">${data.email}</a></td></tr>
                <tr><td style="padding: 6px 0; font-weight: bold; color: #475569;">Phone Number:</td><td style="padding: 6px 0; color: #0f172a; font-weight: 600;">${data.phone}</td></tr>
                <tr><td style="padding: 6px 0; font-weight: bold; color: #475569;">Company / Facility:</td><td style="padding: 6px 0; color: #0f172a; font-weight: 600;">${data.company}</td></tr>
                <tr><td style="padding: 6px 0; font-weight: bold; color: #475569;">Custom Quote Request:</td><td style="padding: 6px 0; color: ${data.isQuoteInquiry ? '#b45309' : '#0f172a'}; font-weight: bold;">${data.isQuoteInquiry ? 'YES (Priority Quote Flagged)' : 'No (Standard Inquiry)'}</td></tr>
              </table>
            </td>
          </tr>

          <!-- Section 2: Logistics Specifications -->
          <tr>
            <td style="padding: 10px 24px;">
              <h3 style="margin: 0 0 12px 0; font-size: 13px; font-weight: 800; text-transform: uppercase; color: #1e3a8a; letter-spacing: 0.5px; border-bottom: 2px solid #dbeafe; padding-bottom: 6px;">
                2. Category Logistics Specifications
              </h3>
              <div style="margin-bottom: 8px; font-size: 13px; font-weight: bold; color: #2563eb;">Category: ${data.subject}</div>
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 12px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; background-color: #f8fafc;">
                ${categorySpecsHtml}
              </table>
            </td>
          </tr>

          <!-- Section 3: Message -->
          <tr>
            <td style="padding: 10px 24px 24px 24px;">
              <h3 style="margin: 0 0 12px 0; font-size: 13px; font-weight: 800; text-transform: uppercase; color: #1e3a8a; letter-spacing: 0.5px; border-bottom: 2px solid #dbeafe; padding-bottom: 6px;">
                3. Inquiry Detail / Message
              </h3>
              <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; font-size: 13px; line-height: 1.6; color: #1e293b; white-space: pre-wrap;">${data.message}</div>
            </td>
          </tr>

          <!-- Footer -->
          <tr style="background-color: #f1f5f9; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b;">
            <td style="padding: 16px 24px; text-align: center;">
              Sent to <strong>${TARGET_RECIPIENT}</strong> &bull; Omnee Courier Solutions LLC &bull; Flagstaff, Arizona &bull; 928-547-1058
            </td>
          </tr>
        </table>
      </body>
    </html>
  `;
}

/**
 * Express handler for POST /api/submit-intake
 */
export async function handleIntakeSubmission(req: Request, res: Response) {
  try {
    const data: IntakeRequestBody = req.body;

    // Validate Baseline Required Fields
    if (!data.name?.trim() || !data.email?.trim() || !data.phone?.trim() || !data.company?.trim() || !data.message?.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Missing required baseline fields (Name, Email, Phone, Company, or Message).'
      });
    }

    // Validate Category-specific requirements
    if (data.subject === 'STAT Emergency Dispatch') {
      const stat = data.categoryData?.statSpecs;
      if (!stat?.pickupAddressFacility?.trim() || !stat?.destinationAddressFacility?.trim() || !stat?.onSitePickupContactPhone?.trim()) {
        return res.status(400).json({
          success: false,
          error: 'STAT Emergency Dispatch requires Pickup Address, Destination Address, and On-Site Phone.'
        });
      }
    }

    // Format Subject Line: [DISPATCH TICKET] {Category} - {Company Name} ({Contact Name})
    const subjectLine = `[DISPATCH TICKET] ${data.subject} - ${data.company} (${data.name})`;
    const htmlBody = buildIntakeEmailHtml(data);

    // If utilizing Nodemailer or SendGrid server-side:
    // Example:
    // await transporter.sendMail({
    //   from: '"Omnee Intake Portal" <no-reply@omneecourier.com>',
    //   to: TARGET_RECIPIENT,
    //   replyTo: data.email,
    //   subject: subjectLine,
    //   html: htmlBody
    // });

    return res.status(200).json({
      success: true,
      message: `Dispatch ticket successfully transmitted to ${TARGET_RECIPIENT}`,
      subject: subjectLine,
      recipient: TARGET_RECIPIENT
    });
  } catch (err: any) {
    console.error('Server intake processing error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Internal server error processing intake ticket.'
    });
  }
}
