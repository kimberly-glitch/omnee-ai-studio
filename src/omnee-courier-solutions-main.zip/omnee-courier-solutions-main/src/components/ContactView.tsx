import React, { useState } from 'react';
import { FAQS } from '../data';
import { 
  Mail, Phone, MapPin, Clock, Send, CheckCircle2, ChevronDown, ChevronUp, 
  Map, ShieldCheck, HelpCircle, Database, ExternalLink, RefreshCw, AlertCircle,
  Thermometer, Zap, Building2, Moon, FileText, Check, FileCheck
} from 'lucide-react';
import { getAccessToken } from '../googleAuth';
import { logInquiryToSheet } from '../googleWorkspace';
import { 
  sendContactFormEmail, 
  createContactMailto, 
  RECIPIENT_EMAIL, 
  InquiryCategory, 
  ContactSubmissionPayload, 
  DynamicCategoryData 
} from '../emailService';

interface ContactViewProps {
  user: any;
  spreadsheetId: string | null;
  onLogin: () => void;
  isSyncing: boolean;
}

export default function ContactView({ user, spreadsheetId, onLogin, isSyncing }: ContactViewProps) {
  // 1. Always-Visible Baseline Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [isQuoteInquiry, setIsQuoteInquiry] = useState(true); // Default: Checked
  const [subject, setSubject] = useState<InquiryCategory>('Medical Courier Specifications');
  const [message, setMessage] = useState('');

  // 2. Dynamic Layered Fields (State by Category)

  // Category A: Medical Courier Specifications
  const [medTempControl, setMedTempControl] = useState('Ambient (15–25°C)');
  const [medSpecimenTypes, setMedSpecimenTypes] = useState<string[]>(['Blood/Serum', 'Biopsy/Tissue']);
  const [medChainOfCustody, setMedChainOfCustody] = useState<'Yes' | 'No'>('Yes');
  const [medFacilityType, setMedFacilityType] = useState('Outpatient Clinic');

  // Category B: STAT Emergency Dispatch
  const [statPickupAddress, setStatPickupAddress] = useState('');
  const [statDestAddress, setStatDestAddress] = useState('');
  const [statPriorityWindow, setStatPriorityWindow] = useState('Immediate / Direct (<30–45 mins)');
  const [statOnSitePhone, setStatOnSitePhone] = useState('');
  const [statDimensionsWeight, setStatDimensionsWeight] = useState('');

  // Category C: Veterinary Diagnostic Route Setup
  const [vetHospitalLocation, setVetHospitalLocation] = useState('');
  const [vetSweepFrequency, setVetSweepFrequency] = useState('Daily Afternoon Sweep');
  const [vetCutoffTime, setVetCutoffTime] = useState('5:00 PM');
  const [vetDailyCount, setVetDailyCount] = useState('6–20 packages');

  // Category D: Dedicated After-Hours Route Coverage
  const [afterHoursShifts, setAfterHoursShifts] = useState<string[]>([
    'Mon–Fri 5:00 PM – 6:00 AM', 
    'Weekend 24/7'
  ]);
  const [afterHoursAccess, setAfterHoursAccess] = useState('Key / Lockbox');
  const [afterHoursRange, setAfterHoursRange] = useState('Local Flagstaff');

  // Category E: Corporate Account Setup / Billing & Invoicing Query
  const [corpApEmail, setCorpApEmail] = useState('');
  const [corpMonthlyVolume, setCorpMonthlyVolume] = useState('26–100');
  const [corpBillingCycle, setCorpBillingCycle] = useState('Monthly Invoicing');

  // Category F: General Logistics Inquiry
  const [generalTopicSummary, setGeneralTopicSummary] = useState('');

  // Submission & Validation States
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, boolean>>({});
  const [isSending, setIsSending] = useState(false);
  const [lastSubmission, setLastSubmission] = useState<ContactSubmissionPayload | null>(null);

  // FAQ Accordion Active Index State
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(0);

  // Coverage Map Interactive Tab State
  const [activeZone, setActiveZone] = useState<'local' | 'regional' | 'national'>('local');

  const coverageZones = {
    local: {
      title: 'Local Flagstaff (Immediate)',
      description: 'Our core immediate-response zone. Direct point-to-point courier dispatches are handled entirely by climate-secure vehicles or localized clinical delivery runners.',
      cities: 'Flagstaff, Bellemont, Parks, Winona, and immediate Flagstaff Medical District areas.',
      rates: 'Starting at $25.00 flat + local mileage.',
      deliveryTime: 'STAT or Scheduled options'
    },
    regional: {
      title: 'Coconino County & Northern Arizona',
      description: 'Regional logistics connections and dedicated scheduled route clinical dispatches covering major medical corridors throughout northern Arizona.',
      cities: 'Sedona, Williams, Munds Park, Grand Canyon Village, Camp Verde, Cottonwood.',
      rates: 'Starting at $55.00 base + regional mileage.',
      deliveryTime: 'Same-Day or Scheduled routes'
    },
    national: {
      title: 'Interstate Logistics',
      description: 'Specialized courier routing and expedited transit linking Northern Arizona with Phoenix, Tucson, and cross-state medical systems.',
      cities: 'Phoenix, Scottsdale, Mesa, Tucson, Prescott, and surrounding hospital systems.',
      rates: 'Expedited transport starting at $120.00.',
      deliveryTime: 'Same-Day or Next-Day guarantees'
    }
  };

  // Helper toggle for multi-select checkboxes
  const toggleCheckboxItem = (
    currentList: string[], 
    setList: React.Dispatch<React.SetStateAction<string[]>>, 
    item: string
  ) => {
    if (currentList.includes(item)) {
      setList(currentList.filter(i => i !== item));
    } else {
      setList([...currentList, item]);
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, boolean> = {};

    // 1. Validate Baseline Required Fields
    if (!name.trim()) errors.name = true;
    if (!email.trim() || !email.includes('@')) errors.email = true;
    if (!phone.trim()) errors.phone = true;
    if (!company.trim()) errors.company = true;
    if (!message.trim()) errors.message = true;

    // 2. Validate Category-Specific Fields
    if (subject === 'STAT Emergency Dispatch') {
      if (!statPickupAddress.trim()) errors.statPickupAddress = true;
      if (!statDestAddress.trim()) errors.statDestAddress = true;
      if (!statOnSitePhone.trim()) errors.statOnSitePhone = true;
    } else if (subject === 'Medical Courier Specifications') {
      if (medSpecimenTypes.length === 0) errors.medSpecimenTypes = true;
    } else if (subject === 'Dedicated After-Hours Route Coverage') {
      if (afterHoursShifts.length === 0) errors.afterHoursShifts = true;
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setValidationError('Please complete all highlighted required logistics fields before submitting.');
      return;
    }

    setFieldErrors({});
    setValidationError('');
    setIsSending(true);

    // Assemble category specific payload
    const categoryData: DynamicCategoryData = {};
    if (subject === 'Medical Courier Specifications') {
      categoryData.medicalSpecs = {
        temperatureControl: medTempControl,
        specimenTypes: medSpecimenTypes,
        chainOfCustodyDoc: medChainOfCustody,
        facilityPickupType: medFacilityType
      };
    } else if (subject === 'STAT Emergency Dispatch') {
      categoryData.statSpecs = {
        pickupAddressFacility: statPickupAddress,
        destinationAddressFacility: statDestAddress,
        dispatchPriorityWindow: statPriorityWindow,
        onSitePickupContactPhone: statOnSitePhone,
        packageDimensionsWeight: statDimensionsWeight
      };
    } else if (subject === 'Veterinary Diagnostic Route Setup') {
      categoryData.vetSpecs = {
        animalHospitalClinicLocation: vetHospitalLocation,
        sweepFrequency: vetSweepFrequency,
        targetCutoffTime: vetCutoffTime,
        estimatedDailyCount: vetDailyCount
      };
    } else if (subject === 'Dedicated After-Hours Route Coverage') {
      categoryData.afterHoursSpecs = {
        coverageShifts: afterHoursShifts,
        facilityAccessProtocol: afterHoursAccess,
        coverageRange: afterHoursRange
      };
    } else if (subject === 'Corporate Account Setup / Billing & Invoicing Query') {
      categoryData.corporateSpecs = {
        accountsPayableEmail: corpApEmail,
        estimatedMonthlyVolume: corpMonthlyVolume,
        preferredBillingCycle: corpBillingCycle
      };
    } else if (subject === 'General Logistics Inquiry') {
      categoryData.generalSpecs = {
        topicSummary: generalTopicSummary
      };
    }

    const payload: ContactSubmissionPayload = {
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      company: company.trim(),
      isQuoteInquiry,
      subject,
      categoryData,
      message: message.trim()
    };

    setLastSubmission(payload);

    try {
      // 1. Direct email dispatch to info@omneecourier.com
      await sendContactFormEmail(payload);

      // 2. Google Workspace Sheet sync if logged in
      if (user && spreadsheetId) {
        try {
          const token = await getAccessToken();
          if (token) {
            await logInquiryToSheet(token, spreadsheetId, {
              name: payload.name,
              email: payload.email,
              phone: payload.phone,
              company: payload.company,
              subject: payload.subject,
              isQuoteInquiry: payload.isQuoteInquiry,
              message: payload.message
            });
          }
        } catch (wsErr) {
          console.warn('Sheets sync notice:', wsErr);
        }
      }

      setFormSubmitted(true);
    } catch (err: any) {
      console.error('Error submitting form:', err);
      // Graceful completion with mailto fallback
      setFormSubmitted(true);
    } finally {
      setIsSending(false);
    }
  };

  const resetForm = () => {
    setFormSubmitted(false);
    setName('');
    setEmail('');
    setPhone('');
    setCompany('');
    setIsQuoteInquiry(true);
    setSubject('Medical Courier Specifications');
    setMessage('');
    setStatPickupAddress('');
    setStatDestAddress('');
    setStatOnSitePhone('');
    setStatDimensionsWeight('');
    setVetHospitalLocation('');
    setCorpApEmail('');
    setGeneralTopicSummary('');
    setFieldErrors({});
    setValidationError('');
    setLastSubmission(null);
  };

  const toggleFaq = (index: number) => {
    if (activeFaqIndex === index) {
      setActiveFaqIndex(null);
    } else {
      setActiveFaqIndex(index);
    }
  };

  return (
    <div className="space-y-20 pb-20">
      {/* Page Header */}
      <section className="bg-slate-900 text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-slate-800 text-center relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full bg-[radial-gradient(ellipse_60%_50%_at_50%_100%,rgba(37,99,235,0.07),transparent_100%)]"></div>
        <div className="max-w-4xl mx-auto relative z-10 space-y-4">
          <span className="text-xs font-bold uppercase tracking-widest text-blue-400 block">Contact & Dispatch</span>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Client Logistics Intake Portal
          </h1>
          <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Configure your medical transport parameters, request dedicated route sweeps, or dispatch emergency STAT couriers across Flagstaff and Northern Arizona.
          </p>
        </div>
      </section>

      {/* Main Intake Form Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Form / Success Card */}
          <div className="lg:col-span-7 bg-white border border-slate-200/60 rounded-3xl p-6 sm:p-8 shadow-sm text-left">
            {formSubmitted && lastSubmission ? (
              <div className="py-6 space-y-6 animate-fade-in" id="contact-success-banner">
                <div className="text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto shadow-sm">
                    <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
                  </div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <Mail className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Transmitted to {RECIPIENT_EMAIL}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Dispatch Ticket Transmitted!</h3>
                  <p className="text-sm text-slate-600 max-w-lg mx-auto leading-relaxed">
                    Thank you, <strong className="text-slate-900">{lastSubmission.name}</strong>. Your intake ticket has been generated and dispatched directly to our 24/7 operations desk at <strong className="text-blue-700">{RECIPIENT_EMAIL}</strong>.
                  </p>
                </div>

                {/* Structured Ticket Breakdown */}
                <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 text-xs space-y-4 font-mono">
                  {/* Subject Line Reference */}
                  <div className="bg-slate-900 text-blue-400 p-3 rounded-xl border border-slate-800 text-[11px] break-all">
                    <span className="text-slate-400 block text-[9px] uppercase tracking-wider mb-0.5">Automated Subject Header:</span>
                    <strong className="text-white">[DISPATCH TICKET] {lastSubmission.subject} - {lastSubmission.company} ({lastSubmission.name})</strong>
                  </div>

                  {/* Section 1: Contact Info */}
                  <div className="space-y-1.5 border-b border-slate-200 pb-3">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1 font-sans">
                      <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                      <span>1. Contact & Facility Information</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-slate-700">
                      <div><span className="text-slate-400">Name:</span> <strong className="text-slate-900">{lastSubmission.name}</strong></div>
                      <div><span className="text-slate-400">Email:</span> <strong className="text-slate-900">{lastSubmission.email}</strong></div>
                      <div><span className="text-slate-400">Phone:</span> <strong className="text-slate-900">{lastSubmission.phone}</strong></div>
                      <div><span className="text-slate-400">Facility:</span> <strong className="text-slate-900">{lastSubmission.company}</strong></div>
                      <div><span className="text-slate-400">Quote Flag:</span> <strong className={lastSubmission.isQuoteInquiry ? "text-amber-600" : "text-slate-700"}>{lastSubmission.isQuoteInquiry ? 'Priority Custom Quote' : 'Standard Inquiry'}</strong></div>
                    </div>
                  </div>

                  {/* Section 2: Selected Category Specifications */}
                  <div className="space-y-1.5 border-b border-slate-200 pb-3">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1 font-sans">
                      <FileCheck className="w-3.5 h-3.5 text-blue-600" />
                      <span>2. Tailored Logistics Specifications</span>
                    </div>
                    <div className="text-[11px] text-blue-700 font-bold mb-1">
                      Category: {lastSubmission.subject}
                    </div>

                    {lastSubmission.subject === 'Medical Courier Specifications' && lastSubmission.categoryData?.medicalSpecs && (
                      <div className="space-y-1 text-slate-700">
                        <div><span className="text-slate-400">Temperature Control:</span> <strong>{lastSubmission.categoryData.medicalSpecs.temperatureControl}</strong></div>
                        <div><span className="text-slate-400">Specimen Types:</span> <strong>{lastSubmission.categoryData.medicalSpecs.specimenTypes.join(', ')}</strong></div>
                        <div><span className="text-slate-400">Chain of Custody / Biohazard Doc:</span> <strong>{lastSubmission.categoryData.medicalSpecs.chainOfCustodyDoc}</strong></div>
                        <div><span className="text-slate-400">Facility Type:</span> <strong>{lastSubmission.categoryData.medicalSpecs.facilityPickupType}</strong></div>
                      </div>
                    )}

                    {lastSubmission.subject === 'STAT Emergency Dispatch' && lastSubmission.categoryData?.statSpecs && (
                      <div className="space-y-1 text-slate-700">
                        <div><span className="text-slate-400">Pickup Location:</span> <strong>{lastSubmission.categoryData.statSpecs.pickupAddressFacility}</strong></div>
                        <div><span className="text-slate-400">Destination:</span> <strong>{lastSubmission.categoryData.statSpecs.destinationAddressFacility}</strong></div>
                        <div><span className="text-slate-400">Priority Window:</span> <strong className="text-rose-600">{lastSubmission.categoryData.statSpecs.dispatchPriorityWindow}</strong></div>
                        <div><span className="text-slate-400">On-Site Direct Phone:</span> <strong>{lastSubmission.categoryData.statSpecs.onSitePickupContactPhone}</strong></div>
                        {lastSubmission.categoryData.statSpecs.packageDimensionsWeight && (
                          <div><span className="text-slate-400">Cargo Specs:</span> <strong>{lastSubmission.categoryData.statSpecs.packageDimensionsWeight}</strong></div>
                        )}
                      </div>
                    )}

                    {lastSubmission.subject === 'Veterinary Diagnostic Route Setup' && lastSubmission.categoryData?.vetSpecs && (
                      <div className="space-y-1 text-slate-700">
                        {lastSubmission.categoryData.vetSpecs.animalHospitalClinicLocation && (
                          <div><span className="text-slate-400">Animal Hospital:</span> <strong>{lastSubmission.categoryData.vetSpecs.animalHospitalClinicLocation}</strong></div>
                        )}
                        <div><span className="text-slate-400">Sweep Frequency:</span> <strong>{lastSubmission.categoryData.vetSpecs.sweepFrequency}</strong></div>
                        <div><span className="text-slate-400">Cutoff Time:</span> <strong>{lastSubmission.categoryData.vetSpecs.targetCutoffTime}</strong></div>
                        <div><span className="text-slate-400">Daily Package Count:</span> <strong>{lastSubmission.categoryData.vetSpecs.estimatedDailyCount}</strong></div>
                      </div>
                    )}

                    {lastSubmission.subject === 'Dedicated After-Hours Route Coverage' && lastSubmission.categoryData?.afterHoursSpecs && (
                      <div className="space-y-1 text-slate-700">
                        <div><span className="text-slate-400">Covered Shifts:</span> <strong>{lastSubmission.categoryData.afterHoursSpecs.coverageShifts.join(', ')}</strong></div>
                        <div><span className="text-slate-400">Access Protocol:</span> <strong>{lastSubmission.categoryData.afterHoursSpecs.facilityAccessProtocol}</strong></div>
                        <div><span className="text-slate-400">Coverage Range:</span> <strong>{lastSubmission.categoryData.afterHoursSpecs.coverageRange}</strong></div>
                      </div>
                    )}

                    {lastSubmission.subject === 'Corporate Account Setup / Billing & Invoicing Query' && lastSubmission.categoryData?.corporateSpecs && (
                      <div className="space-y-1 text-slate-700">
                        {lastSubmission.categoryData.corporateSpecs.accountsPayableEmail && (
                          <div><span className="text-slate-400">Accounts Payable:</span> <strong>{lastSubmission.categoryData.corporateSpecs.accountsPayableEmail}</strong></div>
                        )}
                        <div><span className="text-slate-400">Monthly Volume:</span> <strong>{lastSubmission.categoryData.corporateSpecs.estimatedMonthlyVolume} shipments</strong></div>
                        <div><span className="text-slate-400">Billing Cycle:</span> <strong>{lastSubmission.categoryData.corporateSpecs.preferredBillingCycle}</strong></div>
                      </div>
                    )}

                    {lastSubmission.subject === 'General Logistics Inquiry' && lastSubmission.categoryData?.generalSpecs && (
                      <div className="space-y-1 text-slate-700">
                        {lastSubmission.categoryData.generalSpecs.topicSummary && (
                          <div><span className="text-slate-400">Topic Summary:</span> <strong>{lastSubmission.categoryData.generalSpecs.topicSummary}</strong></div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Section 3: Message Detail */}
                  <div className="space-y-1">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1 font-sans">
                      <FileText className="w-3.5 h-3.5 text-blue-600" />
                      <span>3. Inquiry Detail / Message</span>
                    </div>
                    <p className="text-slate-800 whitespace-pre-wrap font-sans text-xs bg-white p-3 rounded-xl border border-slate-200">
                      {lastSubmission.message}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                  <a
                    href={createContactMailto(lastSubmission)}
                    className="bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 font-bold text-xs uppercase tracking-wider px-5 py-3 rounded-xl transition-all flex items-center justify-center gap-1.5"
                  >
                    <Mail className="w-4 h-4 text-blue-600" />
                    <span>Open Prefilled in Mail App</span>
                  </a>
                  <button
                    onClick={resetForm}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs uppercase tracking-wider px-6 py-3 rounded-xl shadow-sm transition-colors cursor-pointer"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse"></span>
                    <h2 className="text-xl font-bold text-slate-900 tracking-tight">Omnee Logistics Intake Portal • Flagstaff, AZ</h2>
                  </div>
                  <p className="text-xs text-slate-500">
                    Flagstaff & Northern Arizona Healthcare Logistics Hub. Fields marked with (<span className="text-blue-600 font-bold">*</span>) are mandatory. Category selection dynamically configures technical parameters.
                  </p>
                </div>

                {/* Google Connection Helper Banner */}
                {!user ? (
                  <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-600">
                    <div className="flex gap-2">
                      <Database className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-slate-800">Google Sheets Audit Log</p>
                        <p className="text-[11px] text-slate-500">Connect Google Workspace to record all inquiries in real-time.</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={onLogin}
                      disabled={isSyncing}
                      className="bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-950 font-bold px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm flex items-center gap-1.5 whitespace-nowrap text-[11px] self-stretch sm:self-auto justify-center transition-all active:scale-95 cursor-pointer"
                    >
                      {isSyncing ? (
                        <>
                          <RefreshCw className="w-3 h-3 animate-spin text-blue-500" />
                          <span>Connecting...</span>
                        </>
                      ) : (
                        <>
                          <Database className="w-3.5 h-3.5 text-blue-500" />
                          <span>Connect Google</span>
                        </>
                      )}
                    </button>
                  </div>
                ) : (
                  <div className="bg-emerald-50/50 border border-emerald-200/50 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-600">
                    <div className="flex gap-2">
                      <Database className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <p className="font-bold text-slate-800">Workspace Sync Enabled 💚</p>
                        <p className="text-[11px] text-slate-500">Inquiries are logged automatically to your corporate spreadsheet.</p>
                      </div>
                    </div>
                    {spreadsheetId && (
                      <a
                        href={`https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`}
                        target="_blank"
                        rel="noreferrer"
                        className="bg-white hover:bg-emerald-50 text-emerald-700 font-bold px-3 py-1.5 rounded-lg border border-emerald-200 shadow-sm flex items-center gap-1.5 whitespace-nowrap text-[11px] self-stretch sm:self-auto justify-center transition-colors"
                      >
                        <span>Open Live Sheet</span>
                        <ExternalLink className="w-3.5 h-3.5 text-emerald-600" />
                      </a>
                    )}
                  </div>
                )}

                <form onSubmit={handleContactSubmit} className="space-y-6">
                  
                  {/* --- 1. ALWAYS-VISIBLE BASELINE FIELDS --- */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 pb-1 border-b border-slate-100">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">1. Contact & Facility Details</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Contact Name */}
                      <div>
                        <label htmlFor="intake-name" className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                          Contact Name <span className="text-blue-600 font-black">*</span>
                        </label>
                        <input
                          type="text"
                          id="intake-name"
                          required
                          placeholder="e.g. Dr. Michael Vance"
                          value={name}
                          onChange={(e) => {
                            setName(e.target.value);
                            if (fieldErrors.name) setFieldErrors({ ...fieldErrors, name: false });
                          }}
                          className={`w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 text-slate-800 font-semibold transition-all ${
                            fieldErrors.name 
                              ? 'border-rose-400 focus:border-rose-600 focus:ring-rose-500/20 bg-rose-50/20' 
                              : 'border-slate-200 focus:border-blue-600 focus:ring-blue-500/10'
                          }`}
                        />
                      </div>

                      {/* Email Address */}
                      <div>
                        <label htmlFor="intake-email" className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                          Email Address <span className="text-blue-600 font-black">*</span>
                        </label>
                        <input
                          type="email"
                          id="intake-email"
                          required
                          placeholder="e.g. mvance@flagstaffclinic.com"
                          value={email}
                          onChange={(e) => {
                            setEmail(e.target.value);
                            if (fieldErrors.email) setFieldErrors({ ...fieldErrors, email: false });
                          }}
                          className={`w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 text-slate-800 font-semibold transition-all ${
                            fieldErrors.email 
                              ? 'border-rose-400 focus:border-rose-600 focus:ring-rose-500/20 bg-rose-50/20' 
                              : 'border-slate-200 focus:border-blue-600 focus:ring-blue-500/10'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Phone Number */}
                      <div>
                        <label htmlFor="intake-phone" className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                          Phone Number <span className="text-blue-600 font-black">*</span>
                        </label>
                        <input
                          type="tel"
                          id="intake-phone"
                          required
                          placeholder="e.g. 928-555-0199"
                          value={phone}
                          onChange={(e) => {
                            setPhone(e.target.value);
                            if (fieldErrors.phone) setFieldErrors({ ...fieldErrors, phone: false });
                          }}
                          className={`w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 text-slate-800 font-semibold transition-all ${
                            fieldErrors.phone 
                              ? 'border-rose-400 focus:border-rose-600 focus:ring-rose-500/20 bg-rose-50/20' 
                              : 'border-slate-200 focus:border-blue-600 focus:ring-blue-500/10'
                          }`}
                        />
                      </div>

                      {/* Company / Facility Name */}
                      <div>
                        <label htmlFor="intake-company" className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                          Company / Facility Name <span className="text-blue-600 font-black">*</span>
                        </label>
                        <input
                          type="text"
                          id="intake-company"
                          required
                          placeholder="e.g. Northern Arizona Medical District"
                          value={company}
                          onChange={(e) => {
                            setCompany(e.target.value);
                            if (fieldErrors.company) setFieldErrors({ ...fieldErrors, company: false });
                          }}
                          className={`w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 text-slate-800 font-semibold transition-all ${
                            fieldErrors.company 
                              ? 'border-rose-400 focus:border-rose-600 focus:ring-rose-500/20 bg-rose-50/20' 
                              : 'border-slate-200 focus:border-blue-600 focus:ring-blue-500/10'
                          }`}
                        />
                      </div>
                    </div>

                    {/* Custom Quote Request Toggle */}
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                      <div className="space-y-0.5 text-left">
                        <span className="block text-xs font-bold text-slate-900">Custom Quote Request Toggle</span>
                        <span className="block text-[11px] text-slate-500">Flags this ticket for priority dispatcher cost analysis and scheduling.</span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={isQuoteInquiry} 
                          onChange={() => setIsQuoteInquiry(!isQuoteInquiry)} 
                          className="sr-only peer" 
                        />
                        <div className="w-11 h-6 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>

                    {/* Inquiry Category Dropdown */}
                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <label htmlFor="intake-category" className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                          Inquiry Category <span className="text-blue-600 font-black">*</span>
                        </label>
                        <span className="text-[10px] text-blue-600 font-semibold uppercase tracking-wider">Reveals tailored specifications</span>
                      </div>
                      <select
                        id="intake-category"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value as InquiryCategory)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-600 text-slate-900 font-bold transition-all shadow-sm cursor-pointer"
                      >
                        <option value="Medical Courier Specifications">Category A: Medical Courier Specifications</option>
                        <option value="STAT Emergency Dispatch">Category B: STAT Emergency Dispatch</option>
                        <option value="Veterinary Diagnostic Route Setup">Category C: Veterinary Diagnostic Route Setup</option>
                        <option value="Dedicated After-Hours Route Coverage">Category D: Dedicated After-Hours Route Coverage</option>
                        <option value="Corporate Account Setup / Billing & Invoicing Query">Category E: Corporate Account Setup / Billing & Invoicing Query</option>
                        <option value="General Logistics Inquiry">Category F: General Logistics Inquiry</option>
                      </select>
                    </div>
                  </div>

                  {/* --- 2. DYNAMIC LAYERED FIELDS (CONDITIONAL BY CATEGORY) --- */}
                  <div className="pt-2">
                    
                    {/* Category A: Medical Courier Specifications */}
                    {subject === 'Medical Courier Specifications' && (
                      <div className="bg-blue-50/40 border border-blue-200/80 rounded-2xl p-5 space-y-5 animate-fade-in text-left">
                        <div className="flex items-center gap-2 pb-2 border-b border-blue-100">
                          <Thermometer className="w-4 h-4 text-blue-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900">
                            Category Specifications: Medical Courier Logistics
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {/* Temperature Control */}
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Temperature Control Required
                            </label>
                            <select
                              value={medTempControl}
                              onChange={(e) => setMedTempControl(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-blue-600"
                            >
                              <option value="Ambient (15–25°C)">Ambient (15–25°C)</option>
                              <option value="Refrigerated (2–8°C)">Refrigerated (2–8°C)</option>
                              <option value="Frozen (-20°C)">Frozen (-20°C)</option>
                              <option value="Dry Ice (-78.5°C)">Dry Ice (-78.5°C)</option>
                            </select>
                          </div>

                          {/* Facility Pickup Type */}
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Facility Pickup Type
                            </label>
                            <select
                              value={medFacilityType}
                              onChange={(e) => setMedFacilityType(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-blue-600"
                            >
                              <option value="Hospital">Hospital</option>
                              <option value="Reference Lab">Reference Lab</option>
                              <option value="Outpatient Clinic">Outpatient Clinic</option>
                              <option value="Urgent Care">Urgent Care</option>
                              <option value="Pharmacy">Pharmacy</option>
                            </select>
                          </div>
                        </div>

                        {/* Specimen / Transport Type Checkboxes */}
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">
                            Specimen / Transport Type <span className="text-blue-600 font-black">*</span>
                          </label>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                            {['Blood/Serum', 'Biopsy/Tissue', 'Pathological', 'OTC/Pharma', 'Medical Supplies'].map((item) => {
                              const isChecked = medSpecimenTypes.includes(item);
                              return (
                                <button
                                  type="button"
                                  key={item}
                                  onClick={() => toggleCheckboxItem(medSpecimenTypes, setMedSpecimenTypes, item)}
                                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold text-left transition-all ${
                                    isChecked
                                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                      : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                                  }`}
                                >
                                  <div className={`w-3.5 h-3.5 rounded flex items-center justify-center border ${
                                    isChecked ? 'bg-white text-blue-600 border-white' : 'border-slate-300'
                                  }`}>
                                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                                  </div>
                                  <span>{item}</span>
                                </button>
                              );
                            })}
                          </div>
                          {fieldErrors.medSpecimenTypes && (
                            <p className="text-[11px] text-rose-600 font-semibold mt-1">Please select at least one specimen or transport type.</p>
                          )}
                        </div>

                        {/* Chain of Custody Documentation */}
                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">
                            Chain of Custody / Biohazard Documentation Required?
                          </label>
                          <div className="flex gap-4">
                            <label className="inline-flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-800">
                              <input
                                type="radio"
                                name="medChainDoc"
                                checked={medChainOfCustody === 'Yes'}
                                onChange={() => setMedChainOfCustody('Yes')}
                                className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                              />
                              <span>Yes (Mandatory Bio-manifest & Signature)</span>
                            </label>
                            <label className="inline-flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-800">
                              <input
                                type="radio"
                                name="medChainDoc"
                                checked={medChainOfCustody === 'No'}
                                onChange={() => setMedChainOfCustody('No')}
                                className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                              />
                              <span>No</span>
                            </label>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Category B: STAT Emergency Dispatch */}
                    {subject === 'STAT Emergency Dispatch' && (
                      <div className="bg-rose-50/40 border border-rose-200/80 rounded-2xl p-5 space-y-4 animate-fade-in text-left">
                        <div className="flex items-center gap-2 pb-2 border-b border-rose-100">
                          <Zap className="w-4 h-4 text-rose-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-rose-900">
                            Category Specifications: STAT Emergency Dispatch
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Pickup Address & Facility Name <span className="text-rose-600 font-black">*</span>
                            </label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. Flagstaff Medical Center, 1200 N Beaver St"
                              value={statPickupAddress}
                              onChange={(e) => {
                                setStatPickupAddress(e.target.value);
                                if (fieldErrors.statPickupAddress) setFieldErrors({ ...fieldErrors, statPickupAddress: false });
                              }}
                              className={`w-full bg-white border rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 ${
                                fieldErrors.statPickupAddress ? 'border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 focus:border-rose-600 focus:ring-rose-500/10'
                              }`}
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Destination Address & Facility Name <span className="text-rose-600 font-black">*</span>
                            </label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. Sedona Regional Clinic, 3700 W Hwy 89A"
                              value={statDestAddress}
                              onChange={(e) => {
                                setStatDestAddress(e.target.value);
                                if (fieldErrors.statDestAddress) setFieldErrors({ ...fieldErrors, statDestAddress: false });
                              }}
                              className={`w-full bg-white border rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 ${
                                fieldErrors.statDestAddress ? 'border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 focus:border-rose-600 focus:ring-rose-500/10'
                              }`}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Dispatch Priority Window
                            </label>
                            <select
                              value={statPriorityWindow}
                              onChange={(e) => setStatPriorityWindow(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-rose-600"
                            >
                              <option value="Immediate / Direct (<30–45 mins)">Immediate / Direct (&lt;30–45 mins)</option>
                              <option value="Within 1 Hour">Within 1 Hour</option>
                              <option value="Scheduled Time Today">Scheduled Time Today</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              On-Site Pickup Contact Direct Phone <span className="text-rose-600 font-black">*</span>
                            </label>
                            <input
                              type="tel"
                              required
                              placeholder="e.g. 928-555-0144 (Desk/Pager)"
                              value={statOnSitePhone}
                              onChange={(e) => {
                                setStatOnSitePhone(e.target.value);
                                if (fieldErrors.statOnSitePhone) setFieldErrors({ ...fieldErrors, statOnSitePhone: false });
                              }}
                              className={`w-full bg-white border rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 ${
                                fieldErrors.statOnSitePhone ? 'border-rose-500 focus:ring-rose-500/20' : 'border-slate-200 focus:border-rose-600 focus:ring-rose-500/10'
                              }`}
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                            Package / Specimen Dimensions & Weight (Optional)
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. 1 vial in insulated shipper, approx 3 lbs, 8x6x4 inches"
                            value={statDimensionsWeight}
                            onChange={(e) => setStatDimensionsWeight(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-rose-600"
                          />
                        </div>
                      </div>
                    )}

                    {/* Category C: Veterinary Diagnostic Route Setup */}
                    {subject === 'Veterinary Diagnostic Route Setup' && (
                      <div className="bg-emerald-50/40 border border-emerald-200/80 rounded-2xl p-5 space-y-4 animate-fade-in text-left">
                        <div className="flex items-center gap-2 pb-2 border-b border-emerald-100">
                          <Building2 className="w-4 h-4 text-emerald-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900">
                            Category Specifications: Veterinary Diagnostic Route Setup
                          </h4>
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                            Animal Hospital / Clinic Name & Location
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Flagstaff Pet Hospital, 1300 S Milton Rd"
                            value={vetHospitalLocation}
                            onChange={(e) => setVetHospitalLocation(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-emerald-600"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Sweep Frequency
                            </label>
                            <select
                              value={vetSweepFrequency}
                              onChange={(e) => setVetSweepFrequency(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:outline-none focus:border-emerald-600"
                            >
                              <option value="Daily Afternoon Sweep">Daily Afternoon Sweep</option>
                              <option value="Daily Evening Sweep">Daily Evening Sweep</option>
                              <option value="Mon–Fri Recurring">Mon–Fri Recurring</option>
                              <option value="Custom">Custom Schedule</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Target Cutoff Time
                            </label>
                            <select
                              value={vetCutoffTime}
                              onChange={(e) => setVetCutoffTime(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:outline-none focus:border-emerald-600"
                            >
                              <option value="3:00 PM">3:00 PM</option>
                              <option value="4:00 PM">4:00 PM</option>
                              <option value="5:00 PM">5:00 PM</option>
                              <option value="6:00 PM">6:00 PM</option>
                              <option value="7:00 PM">7:00 PM</option>
                              <option value="Custom">Custom Cutoff</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Est. Daily Package Count
                            </label>
                            <select
                              value={vetDailyCount}
                              onChange={(e) => setVetDailyCount(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:outline-none focus:border-emerald-600"
                            >
                              <option value="1–5 packages">1–5 packages</option>
                              <option value="6–20 packages">6–20 packages</option>
                              <option value="20+ packages">20+ packages</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Category D: Dedicated After-Hours Route Coverage */}
                    {subject === 'Dedicated After-Hours Route Coverage' && (
                      <div className="bg-indigo-50/40 border border-indigo-200/80 rounded-2xl p-5 space-y-4 animate-fade-in text-left">
                        <div className="flex items-center gap-2 pb-2 border-b border-indigo-100">
                          <Moon className="w-4 h-4 text-indigo-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                            Category Specifications: Dedicated After-Hours Route Coverage
                          </h4>
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">
                            Coverage Shift Needed <span className="text-indigo-600 font-black">*</span>
                          </label>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                            {[
                              'Mon–Fri 5:00 PM – 6:00 AM', 
                              'Weekend 24/7', 
                              'Holiday Coverage'
                            ].map((shift) => {
                              const isChecked = afterHoursShifts.includes(shift);
                              return (
                                <button
                                  type="button"
                                  key={shift}
                                  onClick={() => toggleCheckboxItem(afterHoursShifts, setAfterHoursShifts, shift)}
                                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold text-left transition-all ${
                                    isChecked
                                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                                      : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                                  }`}
                                >
                                  <div className={`w-3.5 h-3.5 rounded flex items-center justify-center border ${
                                    isChecked ? 'bg-white text-indigo-600 border-white' : 'border-slate-300'
                                  }`}>
                                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                                  </div>
                                  <span>{shift}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Facility Access Protocol
                            </label>
                            <select
                              value={afterHoursAccess}
                              onChange={(e) => setAfterHoursAccess(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-indigo-600"
                            >
                              <option value="Key / Lockbox">Key / Lockbox</option>
                              <option value="Security Badge">Security Badge</option>
                              <option value="On-Site Staff Meet">On-Site Staff Meet</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Service Coverage Range
                            </label>
                            <select
                              value={afterHoursRange}
                              onChange={(e) => setAfterHoursRange(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-indigo-600"
                            >
                              <option value="Local Flagstaff">Local Flagstaff</option>
                              <option value="Northern Arizona Regional">Northern Arizona Regional</option>
                              <option value="Interstate / Long-Haul">Interstate / Long-Haul</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Category E: Corporate Account Setup / Billing & Invoicing Query */}
                    {subject === 'Corporate Account Setup / Billing & Invoicing Query' && (
                      <div className="bg-amber-50/40 border border-amber-200/80 rounded-2xl p-5 space-y-4 animate-fade-in text-left">
                        <div className="flex items-center gap-2 pb-2 border-b border-amber-100">
                          <Building2 className="w-4 h-4 text-amber-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                            Category Specifications: Corporate Account Setup & Invoicing
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Accounts Payable Email
                            </label>
                            <input
                              type="email"
                              placeholder="e.g. ap@healthcare.org"
                              value={corpApEmail}
                              onChange={(e) => setCorpApEmail(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-amber-600"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Monthly Shipment Volume
                            </label>
                            <select
                              value={corpMonthlyVolume}
                              onChange={(e) => setCorpMonthlyVolume(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-amber-600"
                            >
                              <option value="1–25">1–25 Shipments / Mo</option>
                              <option value="26–100">26–100 Shipments / Mo</option>
                              <option value="100+">100+ Shipments / Mo</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                              Preferred Billing Cycle
                            </label>
                            <select
                              value={corpBillingCycle}
                              onChange={(e) => setCorpBillingCycle(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-amber-600"
                            >
                              <option value="Weekly">Weekly Invoicing</option>
                              <option value="Bi-Weekly">Bi-Weekly Invoicing</option>
                              <option value="Monthly Invoicing">Monthly Invoicing (Net-30)</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Category F: General Logistics Inquiry */}
                    {subject === 'General Logistics Inquiry' && (
                      <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 space-y-3 animate-fade-in text-left">
                        <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                          <HelpCircle className="w-4 h-4 text-slate-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                            Category Specifications: General Logistics Overview
                          </h4>
                        </div>

                        <div>
                          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                            Inquiry Topic Summary
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. Rate quote for specialized pharmaceutical cold-chain run"
                            value={generalTopicSummary}
                            onChange={(e) => setGeneralTopicSummary(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-blue-600"
                          />
                        </div>
                      </div>
                    )}

                  </div>

                  {/* --- 3. INQUIRY DETAIL / MESSAGE (REQUIRED) --- */}
                  <div>
                    <label htmlFor="intake-message" className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                      Inquiry Detail / Message <span className="text-blue-600 font-black">*</span>
                    </label>
                    <textarea
                      id="intake-message"
                      rows={5}
                      required
                      value={message}
                      onChange={(e) => {
                        setMessage(e.target.value);
                        if (fieldErrors.message) setFieldErrors({ ...fieldErrors, message: false });
                      }}
                      placeholder="Please details parameters of your shipping volume, special medical requirements, or general logistics questions here..."
                      className={`w-full bg-slate-50 border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 text-slate-800 font-semibold placeholder:font-normal placeholder:text-slate-400 transition-all ${
                        fieldErrors.message
                          ? 'border-rose-400 focus:border-rose-600 focus:ring-rose-500/20 bg-rose-50/20'
                          : 'border-slate-200 focus:border-blue-600 focus:ring-blue-500/10'
                      }`}
                    />
                  </div>

                  {validationError && (
                    <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-700 font-bold">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{validationError}</span>
                    </div>
                  )}

                  {/* Dispatch routing info notice */}
                  <div className="bg-slate-900 text-white rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-blue-400 shrink-0" />
                      <span className="text-slate-300">
                        Target Recipient: <strong className="text-white font-mono">{RECIPIENT_EMAIL}</strong>
                      </span>
                    </div>
                    <span className="text-[10px] text-blue-400 font-mono hidden sm:inline uppercase">
                      24/7 Monitored Dispatch
                    </span>
                  </div>

                  <button
                    type="submit"
                    disabled={isSending}
                    className="w-full bg-blue-700 hover:bg-blue-800 disabled:bg-slate-700 text-white font-bold uppercase tracking-wider py-4 rounded-xl transition-all shadow-md text-xs flex items-center justify-center gap-2 active:scale-95 disabled:scale-100 disabled:opacity-80 cursor-pointer"
                    id="contact-submit-btn"
                  >
                    {isSending ? (
                      <>
                        <span>Transmitting Dispatch Ticket to {RECIPIENT_EMAIL}...</span>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      </>
                    ) : (
                      <>
                        <span>Submit Intake Ticket & Email Dispatch</span>
                        <Send className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}
          </div>

          {/* Right Column: Direct Info & Accolades */}
          <div className="lg:col-span-5 space-y-6 text-left">
            
            {/* Direct Info Card */}
            <div className="bg-slate-900 text-white border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
              <h3 className="text-lg font-bold border-b border-slate-800 pb-3">Omnee Operations Office</h3>
              
              <div className="space-y-5 text-sm">
                {/* HQ address */}
                <div className="flex gap-3.5">
                  <div className="p-2.5 bg-slate-800 text-blue-400 rounded-xl shrink-0 h-fit border border-slate-700">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">Service Area</span>
                    <span className="block font-semibold text-slate-200 mt-1">
                      Headquartered in Flagstaff, Arizona, proudly serving local clinics and regional healthcare facilities.
                    </span>
                  </div>
                </div>

                {/* Telephone */}
                <div className="flex gap-3.5">
                  <div className="p-2.5 bg-slate-800 text-blue-400 rounded-xl shrink-0 h-fit border border-slate-700">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">Phone</span>
                    <a href="tel:9285471058" className="block font-semibold text-slate-200 hover:text-blue-400 transition-colors mt-1 font-mono">
                      928-547-1058
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="flex gap-3.5">
                  <div className="p-2.5 bg-slate-800 text-blue-400 rounded-xl shrink-0 h-fit border border-slate-700">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">Email</span>
                    <a href="mailto:Info@Omneecourier.com" className="block font-semibold text-slate-200 hover:text-blue-400 transition-colors mt-1 font-mono">
                      Info@Omneecourier.com
                    </a>
                  </div>
                </div>

                {/* Dispatch Desk Availability */}
                <div className="flex gap-3.5">
                  <div className="p-2.5 bg-slate-800 text-blue-400 rounded-xl shrink-0 h-fit border border-slate-700">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500">Service Hours</span>
                    <div className="space-y-1.5 mt-1">
                      <div className="flex justify-between items-center text-sm font-semibold text-slate-200">
                        <span className="text-slate-400 font-normal">Mon-Fri:</span>
                        <span>5:00 PM - 6:00 AM</span>
                      </div>
                      <div className="flex justify-between items-center text-sm font-semibold text-blue-400">
                        <span className="text-slate-400 font-normal">Weekends:</span>
                        <span>24 Hours</span>
                      </div>
                      <div className="flex justify-between items-center text-sm font-semibold text-blue-400">
                        <span className="text-slate-400 font-normal">Holidays:</span>
                        <span>24 Hours</span>
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-2 leading-relaxed">
                      Emergency STAT dispatch availability considered at all times.
                    </p>
                    <div className="mt-3 pt-3 border-t border-slate-800">
                      <span className="block text-[9px] font-bold uppercase tracking-widest text-slate-600 mb-1">Our Objective</span>
                      <span className="block text-[11px] font-bold text-slate-400">24 Hours a Day • 365 Days a Year</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Regulatory Accolades */}
            <div className="bg-slate-50 border border-slate-200/60 p-6 rounded-3xl space-y-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-700 block">Logistics Assurances</span>
              <div className="flex gap-3">
                <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-slate-900 leading-none">Registered HIPAA Compliant Carrier</h4>
                  <p className="text-[11px] text-slate-500 leading-normal">Fully certified clinical handlers executing medical transport routines with temperature audit stability.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Coverage Map Panel */}
      <section className="bg-slate-50 py-16 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-blue-700 block flex justify-center items-center gap-1">
              <Map className="w-4 h-4" />
              <span>Coverage Ranges</span>
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Interactive Service Mapping</h2>
            <p className="text-slate-500 text-sm">
              We operate dedicated vehicles covering Flagstaff clinics, Northern Arizona healthcare systems, and transport routing. Click on a range below:
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-6">
            {/* Tabs Selector */}
            <div className="bg-white border border-slate-200 p-1.5 rounded-2xl flex gap-1 shadow-sm">
              <button
                onClick={() => setActiveZone('local')}
                className={`flex-1 py-3 text-xs sm:text-sm font-bold tracking-wide uppercase rounded-xl transition-all ${
                  activeZone === 'local'
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Local Flagstaff
              </button>
              <button
                onClick={() => setActiveZone('regional')}
                className={`flex-1 py-3 text-xs sm:text-sm font-bold tracking-wide uppercase rounded-xl transition-all ${
                  activeZone === 'regional'
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Northern Arizona
              </button>
              <button
                onClick={() => setActiveZone('national')}
                className={`flex-1 py-3 text-xs sm:text-sm font-bold tracking-wide uppercase rounded-xl transition-all ${
                  activeZone === 'national'
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Interstate
              </button>
            </div>

            {/* Tab Body Card */}
            <div className="bg-white border border-slate-200/60 rounded-3xl p-6 sm:p-8 text-left shadow-sm grid grid-cols-1 md:grid-cols-12 gap-8 items-center animate-fade-in">
              <div className="md:col-span-7 space-y-4">
                <h3 className="text-lg font-bold text-slate-900 leading-tight">
                  {coverageZones[activeZone].title}
                </h3>
                <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                  {coverageZones[activeZone].description}
                </p>

                <div className="space-y-1 bg-slate-50 p-4 rounded-xl text-xs font-semibold">
                  <div className="text-slate-400 uppercase text-[9px] tracking-wider mb-1">Target Municipalities</div>
                  <p className="text-slate-800">{coverageZones[activeZone].cities}</p>
                </div>
              </div>

              <div className="md:col-span-5 bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-3 font-mono text-xs">
                <span className="block text-slate-500 text-[10px] uppercase">RATES & SPECS</span>
                <div className="flex justify-between border-b border-slate-800 pb-2">
                  <span className="text-slate-400">Tariff Basis:</span>
                  <span className="text-blue-400 font-bold">{coverageZones[activeZone].rates}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Avg Transit Speed:</span>
                  <span className="text-white font-bold">{coverageZones[activeZone].deliveryTime}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4">
          <span className="text-xs font-bold uppercase tracking-widest text-blue-700 block flex justify-center items-center gap-1">
            <HelpCircle className="w-4 h-4" />
            <span>F.A.Q. Center</span>
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Solutions to Common Queries</h2>
          <p className="text-slate-500 text-sm max-w-2xl mx-auto leading-relaxed">
            Need information about STAT delivery speeds, client online APIs, or commercial liabilities? Browse answers to common questions.
          </p>
        </div>

        <div className="space-y-4 text-left">
          {FAQS.map((faq, idx) => {
            const isOpen = activeFaqIndex === idx;
            return (
              <div 
                key={idx} 
                className="bg-white border border-slate-200/60 rounded-2xl overflow-hidden transition-all shadow-sm"
                id={`faq-item-${idx}`}
              >
                <button
                  onClick={() => toggleFaq(idx)}
                  className="w-full flex justify-between items-center px-6 py-5 font-bold text-slate-900 text-sm sm:text-base text-left hover:bg-slate-50/50 transition-colors focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-5 h-5 text-blue-600 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                  )}
                </button>
                
                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-slate-500 text-xs sm:text-sm leading-relaxed border-t border-slate-50 font-medium">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
