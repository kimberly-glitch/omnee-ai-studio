/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navigation, { Footer } from './components/Navigation';
import HomeView from './components/HomeView';
import ServicesView from './components/ServicesView';
import AboutView from './components/AboutView';
import ContactView from './components/ContactView';
import TrackingWidget from './components/TrackingWidget';
import { User } from 'firebase/auth';
import { initAuth, googleSignIn, logout } from './googleAuth';
import { ensureSpreadsheet } from './googleWorkspace';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [trackingOpen, setTrackingOpen] = useState(false);
  const [prefillCode, setPrefillCode] = useState('');

  // Google Workspace / Firebase Auth states
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [spreadsheetId, setSpreadsheetId] = useState<string | null>(localStorage.getItem('omnee_portal_spreadsheet_id'));
  const [isSyncingSheet, setIsSyncingSheet] = useState(false);

  // Initialize Auth state on app load
  useEffect(() => {
    const unsubscribe = initAuth(
      async (firebaseUser, cachedToken) => {
        setUser(firebaseUser);
        setToken(cachedToken);
        if (cachedToken) {
          try {
            setIsSyncingSheet(true);
            const sheetId = await ensureSpreadsheet(cachedToken);
            setSpreadsheetId(sheetId);
          } catch (err) {
            console.error('Error verifying spreadsheet on init:', err);
          } finally {
            setIsSyncingSheet(false);
          }
        }
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleGoogleLogin = async () => {
    try {
      setIsSyncingSheet(true);
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setToken(result.accessToken);
        const sheetId = await ensureSpreadsheet(result.accessToken);
        setSpreadsheetId(sheetId);
      }
    } catch (err) {
      console.error('Google Sign-In failed:', err);
    } finally {
      setIsSyncingSheet(false);
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setToken(null);
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  const handleOpenTrackingModal = (code?: string) => {
    if (code) {
      setPrefillCode(code);
    } else {
      setPrefillCode('');
    }
    setTrackingOpen(true);
  };

  const handleCloseTrackingModal = () => {
    setTrackingOpen(false);
    setPrefillCode('');
  };

  const renderActiveView = () => {
    switch (activeSection) {
      case 'home':
        return (
          <HomeView 
            onNavigate={(section) => {
              setActiveSection(section);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} 
            onOpenTracking={handleOpenTrackingModal} 
          />
        );
      case 'services':
        return (
          <ServicesView 
            onNavigate={(section) => {
              setActiveSection(section);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} 
            user={user}
            spreadsheetId={spreadsheetId}
            onLogin={handleGoogleLogin}
            isSyncing={isSyncingSheet}
          />
        );
      case 'about':
        return <AboutView />;
      case 'contact':
        return (
          <ContactView 
            user={user}
            spreadsheetId={spreadsheetId}
            onLogin={handleGoogleLogin}
            isSyncing={isSyncingSheet}
          />
        );
      default:
        return (
          <HomeView 
            onNavigate={(section) => {
              setActiveSection(section);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }} 
            onOpenTracking={handleOpenTrackingModal} 
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-blue-600 selection:text-white" id="app-root-container">
      {/* Navigation Header */}
      <Navigation 
        activeSection={activeSection} 
        setActiveSection={setActiveSection} 
        onOpenTrackingModal={handleOpenTrackingModal} 
        user={user}
        spreadsheetId={spreadsheetId}
        onLogin={handleGoogleLogin}
        onLogout={handleGoogleLogout}
        isSyncing={isSyncingSheet}
      />

      {/* Main View Area */}
      <main className="flex-grow">
        {renderActiveView()}
      </main>

      {/* Footer */}
      <Footer setActiveSection={setActiveSection} />

      {/* Live Tracking Modal Widget */}
      <TrackingWidget 
        isOpen={trackingOpen} 
        onClose={handleCloseTrackingModal} 
        prefillCode={prefillCode} 
      />
    </div>
  );
}

