/**
 * Google Workspace integration helper for Sheets and Calendar.
 * Uses fetch with the client-side OAuth access token.
 */

export interface InquiryData {
  name: string;
  email: string;
  phone: string;
  company: string;
  subject: string;
  isQuoteInquiry: boolean;
  message: string;
}

export interface BookingData {
  bookingId: string;
  serviceTitle: string;
  originZip: string;
  destZip: string;
  distance: number;
  weight: number;
  urgency: string;
  totalCost: number;
  scheduledTime: string;
}

const PORTAL_SPREADSHEET_KEY = 'omnee_portal_spreadsheet_id';

/**
 * Creates or verifies a Google Sheet for Omnee Courier Portal
 */
export async function ensureSpreadsheet(accessToken: string): Promise<string> {
  const cachedId = localStorage.getItem(PORTAL_SPREADSHEET_KEY);

  if (cachedId) {
    try {
      // Test if spreadsheet exists and is accessible
      const res = await fetch(`https://sheets.googleapis.com/v1/spreadsheets/${cachedId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (res.ok) {
        return cachedId;
      }
    } catch (err) {
      console.warn('Cached spreadsheet invalid or inaccessible. Creating a new one...', err);
    }
  }

  // Create new spreadsheet with "Inquiries" and "Bookings" sheets
  const createResponse = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: 'Omnee Courier Solutions - Dispatch & Inquiry Portal',
      },
      sheets: [
        {
          properties: {
            title: 'Inquiries',
            gridProperties: { rowCount: 1000, columnCount: 10 },
          },
        },
        {
          properties: {
            title: 'Bookings',
            gridProperties: { rowCount: 1000, columnCount: 12 },
          },
        },
      ],
    }),
  });

  if (!createResponse.ok) {
    const errorText = await createResponse.text();
    throw new Error(`Failed to create spreadsheet: ${errorText}`);
  }

  const spreadsheet = await createResponse.json();
  const spreadsheetId = spreadsheet.spreadsheetId;

  // Initialize headers
  await initializeSheetHeaders(accessToken, spreadsheetId);

  localStorage.setItem(PORTAL_SPREADSHEET_KEY, spreadsheetId);
  return spreadsheetId;
}

/**
 * Sets up the column headers for both sheets
 */
async function initializeSheetHeaders(accessToken: string, spreadsheetId: string): Promise<void> {
  const inquiriesHeaders = [
    'Timestamp',
    'Client Name',
    'Email Address',
    'Phone Number',
    'Company',
    'Inquiry Category',
    'Is Custom Quote Request?',
    'Message Detail',
  ];

  const bookingsHeaders = [
    'Timestamp',
    'Booking ID',
    'Service Level',
    'Origin ZIP',
    'Destination ZIP',
    'Distance (Miles)',
    'Weight (Lbs)',
    'Urgency / Dispatch Speed',
    'Total Estimated Cost',
    'Scheduled Time',
  ];

  // Write Inquiries headers
  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Inquiries!A1:H1?valueInputOption=RAW`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: [inquiriesHeaders],
      }),
    }
  );

  // Write Bookings headers
  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bookings!A1:J1?valueInputOption=RAW`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: [bookingsHeaders],
      }),
    }
  );
}

/**
 * Appends an inquiry record to the Google Sheet
 */
export async function logInquiryToSheet(
  accessToken: string,
  spreadsheetId: string,
  inquiry: InquiryData
): Promise<void> {
  const timestamp = new Date().toLocaleString();
  const values = [
    [
      timestamp,
      inquiry.name,
      inquiry.email,
      inquiry.phone || 'N/A',
      inquiry.company || 'N/A',
      inquiry.subject,
      inquiry.isQuoteInquiry ? 'YES' : 'NO',
      inquiry.message,
    ],
  ];

  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Inquiries!A:A:append?valueInputOption=RAW`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range: 'Inquiries!A:A',
        majorDimension: 'ROWS',
        values,
      }),
    }
  );

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Failed to append inquiry to Google Sheets: ${text}`);
  }
}

/**
 * Appends a booking record to the Google Sheet
 */
export async function logBookingToSheet(
  accessToken: string,
  spreadsheetId: string,
  booking: BookingData
): Promise<void> {
  const timestamp = new Date().toLocaleString();
  const values = [
    [
      timestamp,
      booking.bookingId,
      booking.serviceTitle,
      booking.originZip,
      booking.destZip,
      booking.distance,
      booking.weight,
      booking.urgency,
      `$${booking.totalCost.toFixed(2)}`,
      booking.scheduledTime,
    ],
  ];

  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bookings!A:A:append?valueInputOption=RAW`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range: 'Bookings!A:A',
        majorDimension: 'ROWS',
        values,
      }),
    }
  );

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Failed to append booking to Google Sheets: ${text}`);
  }
}

/**
 * Schedules a delivery on the Google Calendar
 */
export async function createCalendarEvent(
  accessToken: string,
  booking: BookingData
): Promise<any> {
  const startTime = new Date(booking.scheduledTime);
  const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // 1-hour duration

  const event = {
    summary: `🚚 Omnee Courier - ${booking.serviceTitle} (${booking.bookingId})`,
    location: `From ZIP ${booking.originZip} to ZIP ${booking.destZip}`,
    description: `Omnee Courier Solutions - Courier Booking Confirmation\n\n` +
                 `Booking ID: ${booking.bookingId}\n` +
                 `Service Level: ${booking.serviceTitle}\n` +
                 `Transit distance: ${booking.distance} Miles\n` +
                 `Package weight: ${booking.weight} Lbs\n` +
                 `Urgency: ${booking.urgency}\n` +
                 `Estimated cost: $${booking.totalCost.toFixed(2)}\n\n` +
                 `Status: Pending Dispatch assignment.\n` +
                 `Thank you for trusting Omnee with your premium medical transport!`,
    start: {
      dateTime: startTime.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Phoenix',
    },
    end: {
      dateTime: endTime.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Phoenix',
    },
    reminders: {
      useDefault: true,
    },
  };

  const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(event),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Failed to create calendar event: ${text}`);
  }

  return await res.json();
}
